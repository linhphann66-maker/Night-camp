import {validatePet} from './pets/runtime.mjs';
export const SOCKETS=['head','face','handF','handB','back'];
export function validateAttachments(list=[]){
 if(!Array.isArray(list)||list.length>32)throw Error('Tối đa 32 phụ kiện');
 const ids=new Set();for(const a of list){
  if(!a||typeof a.id!=='string'||ids.has(a.id)||typeof a.name!=='string'||!SOCKETS.includes(a.socket)||!['front','back'].includes(a.layer))throw Error('Phụ kiện hoặc điểm gắn không hợp lệ');ids.add(a.id);
  if(typeof a.src!=='string'||!(/^assets\/[\w./-]+\.(png|webp|jpg)$/.test(a.src)||/^data:image\/(png|webp);base64,[A-Za-z0-9+/=]+$/.test(a.src)))throw Error('Ảnh phụ kiện không hợp lệ');
  if(![a.w,a.h,a.scale,a.x,a.y,a.rotation].every(Number.isFinite)||a.w<1||a.h<1||a.w>2000||a.h>2000||a.scale<.05||a.scale>10||Math.abs(a.x)>2000||Math.abs(a.y)>2000||Math.abs(a.rotation)>Math.PI*20)throw Error('Kích thước / góc phụ kiện không hợp lệ');
  if(!Array.isArray(a.anchor)||a.anchor.length!==2||!a.anchor.every(v=>Number.isFinite(v)&&v>=0&&v<=1))throw Error('Điểm neo phải nằm trong ảnh');
  if(a.wingRig!==undefined){if(a.socket!=='back'||a.layer!=='back')throw Error('Rig cánh phải gắn sau lưng');validatePet(a.wingRig)}
  if(a.headFit!==undefined){const f=a.headFit,points=(ps,min,max)=>Array.isArray(ps)&&ps.length===3&&ps.every(p=>Array.isArray(p)&&p.length===2&&p.every(v=>Number.isFinite(v)&&v>=min&&v<=max));if(!f||f.version!==1||!['silhouette-core','manual'].includes(f.method)||!points(f.points,0,1)||!points(f.target,-2,3)||!Number.isFinite(f.confidence)||f.confidence<0||f.confidence>1)throw Error('Mốc ôm đầu không hợp lệ')}
 }
 return list;
}
let sequence=0;
export function makeAttachment(entry,headWidth=72){
 const s=entry.sprite,isWeapon=entry.category==='weapon',glasses=entry.category==='glasses',w=isWeapon?s.w*.95:headWidth*(glasses ? .85 : entry.fit||1.3),h=w*s.h/s.w;
 const lens=glasses&&s.lens,raw=lens?[(lens[0][0]+lens[1][0])/2,(lens[0][1]+lens[1][1])/2]:[s.ax??.5,isWeapon?1-(entry.grip??.2):glasses ? .5 : s.brim??1],anchor=raw.map(v=>Math.max(0,Math.min(1,v)));
 return {id:'attachment_'+Date.now()+'_'+ ++sequence,name:entry.name||entry.id,sourceId:entry.id,src:s.src,socket:isWeapon?'handF':glasses?'face':'head',layer:isWeapon?'back':'front',w,h,scale:1,x:(isWeapon?0:(entry.dx||0)*headWidth)+(anchor[0]-raw[0])*w,y:(isWeapon||glasses?0:(entry.seat||0)*headWidth)+(anchor[1]-raw[1])*h,rotation:0,anchor,visible:true};
}
export function screenDelta(matrix,dx,dy){const det=matrix.a*matrix.d-matrix.b*matrix.c;if(Math.abs(det)<1e-8)throw Error('Không thể kéo ở tỷ lệ này');return [(matrix.d*dx-matrix.c*dy)/det,(-matrix.b*dx+matrix.a*dy)/det]}
